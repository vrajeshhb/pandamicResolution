package com.example.pandemicresolution;


public class donateN{
}